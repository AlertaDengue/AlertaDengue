# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['epi_scanner',
 'epi_scanner.management',
 'epi_scanner.model',
 'epi_scanner.tests']

package_data = \
{'': ['*'], 'epi_scanner': ['assets/*']}

install_requires = \
['SQLAlchemy<2.0',
 'geopandas>=0.12.2,<0.13.0',
 'h2o-wave>=0.23.1,<0.24.0',
 'lmfit>=1.1.0,<2.0.0',
 'loguru>=0.6.0,<0.7.0',
 'mapclassify>=2.5.0,<3.0.0',
 'matplotlib>=3.7.1,<4.0.0',
 'pandas>=1.5.0,<2.0.0',
 'plotly>=5.13.1,<6.0.0',
 'psutil>=5.9.2,<6.0.0',
 'pyarrow>=11.0.0,<12.0.0',
 'python-dotenv>=1.0.0,<2.0.0',
 'typing-extensions>=4.4.0,<5.0.0']

setup_kwargs = {
    'name': 'episcanner',
    'version': '0.1.0',
    'description': 'Dashboard quickstart template',
    'long_description': None,
    'author': 'Flávio Codeço Coelho',
    'author_email': 'fccoelho@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
